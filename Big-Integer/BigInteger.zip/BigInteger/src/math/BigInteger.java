package math;
import java.math.*;
/**
 * This class encapsulates a BigInteger, i.e. a positive or negative integer with 
 * any number of digits, which overcomes the computer storage length limitation of 
 * an integer.
 * 
 */
public class BigInteger {

	/**
	 * True if this is a negative integer
	 */
	boolean negative;
	
	/**
	 * Number of digits in this integer
	 */
	int numDigits;
	
	/**
	 * Reference to the first node of this integer's linked list representation
	 * NOTE: The linked list stores the Least Significant Digit in the FIRST node.
	 * For instance, the integer 235 would be stored as:
	 *    5 --> 3  --> 2
	 */
	DigitNode front;
	
	/**
	 * Initializes this integer to a positive number with zero digits, in other
	 * words this is the 0 (zero) valued integer.
	 */
	public BigInteger() {
		negative = false;
		numDigits = 0;
		front = null;
	}
	
	/**
	 * Parses an input integer string into a corresponding BigInteger instance.
	 * A correctly formatted integer would have an optional sign as the first 
	 * character (no sign means positive), and at least one digit character
	 * (including zero). 
	 * Examples of correct format, with corresponding values
	 *      Format     Value
	 *       +0            0
	 *       -0            0
	 *       +123        123
	 *       1023       1023
	 *       0012         12  
	 *       0             0
	 *       -123       -123
	 *       -001         -1
	 *       +000          0
	 *       
	 * 
	 * @param integer Integer string that is to be parsed
	 * @return BigInteger instance that stores the input integer
	 * @throws IllegalArgumentException If input is incorrectly formatted
	 */
	public static BigInteger parse(String integer) throws IllegalArgumentException {
		// THE FOLLOWING LINE IS A PLACEHOLDER SO THE PROGRAM COMPILES
		// YOU WILL NEED TO CHANGE IT TO RETURN THE APPROPRIATE BigInteger
		
		//made new BigInt object
		BigInteger obj = new BigInteger();
		
		integer = integer.trim();
		
		
		if(integer.equals("")){
			throw new IllegalArgumentException("The string is just spaces");
		}
			
		//if input string has + sign then remove it
		if(integer.charAt(0)== '+')
		{
			if(integer.length()>1)
			integer= integer.substring(1);
			else {
				throw new IllegalArgumentException("The string is just a + with spaces");
			}
		}
		//if input string has - sign it and set boolean to negative.
		else if (integer.charAt(0) =='-')
		{
			if(integer.length()>1){
			obj.negative = true;
			integer = integer.substring(1);
			}
			else {
				throw new IllegalArgumentException("The string is just a - with spaces");
			}
		}

			for(int i=0;i<integer.length();i++)
		{
			//if not all the characters are integers, then stop program.
			if(!Character.isDigit(integer.charAt(i))){
		
				throw new IllegalArgumentException("There is a character in the string that is not an integer (excluding the +/- in the beginning");
				}
			//if 1st digit is 0, then remove it.
			 if(integer.charAt(0)=='0'&& (integer.length()>1))
			{
				integer= integer.substring(1);
				i=i-1;
			}
		}	
			//decides length
			obj.numDigits = integer.length();
	
			 obj.front = new DigitNode(Character.getNumericValue(integer.charAt(0)),null);
			
		DigitNode ptr ; //= new DigitNode(0,obj.front);	
		
		for (int i=1;i<integer.length();i++){
				ptr = new DigitNode(Character.getNumericValue(integer.charAt(i)),obj.front);
				obj.front = ptr;
				
		}
			if(obj.numDigits == 1 && obj.negative == true && obj.front.digit ==0){
				obj.negative = false;
			}
		
		return obj;
	}
	
	
	
	/**
	 * Adds an integer to this integer, and returns the result in a NEW BigInteger object. 
	 * DOES NOT MODIFY this integer.
	 * NOTE that either or both of the integers involved could be negative.
	 * (Which means this method can effectively subtract as well.)
	 * 
	 * @param other Other integer to be added to this integer
	 * @return Result integer
	 */
	public BigInteger add(BigInteger other) {
		
		BigInteger sum = new BigInteger();
		
		DigitNode numB = this.front;	
		DigitNode numS = other.front;
		boolean Bgr8tr = true;
		 
		//if 'numSmall' is > 'numBig'(in terms of magnitude) then switch them.
		//numB has a larger magnitude than numS
		if (this.numDigits<other.numDigits){
			DigitNode temp = numB;
			numB = numS;
			numS = temp;
			Bgr8tr = false;
		}
		int countSwitch =0;
		// if both have same # digits and one is positive and one is negative, find which has greater magnitude 
		//magnitude doesn't matter
		if(((!this.negative && other.negative)||(this.negative && !other.negative))&& (this.numDigits == other.numDigits)){
		
			DigitNode temp1 = this.front;
			DigitNode temp2 = other.front;
			
			while(temp1.next !=null){
				//System.out.println(temp1.digit+temp2.digit);
				if(temp1.digit>temp2.digit){
					Bgr8tr = true;
					countSwitch++;
				}
				else if(temp1.digit<temp2.digit){
					Bgr8tr = false;
					countSwitch++;
				}
				
				temp1 = temp1.next;
				temp2 = temp2.next;
				
			}
			if(countSwitch==0){
				sum.negative=false;
				sum.front = new DigitNode(0,null);
				sum.numDigits = 1;
				
				return sum;
			}
			// now numB is has greater magnitude regardless of size of Linked Lists.
			if(Bgr8tr == false){
				DigitNode temp = numB;
				numB = numS;
				numS = temp;
			}
		}
		
		int sizeSmall=0,sizeLg = 0;
		Boolean bNeg = false, sNeg = false;
		if((numB == this.front && numS == other.front)){
			sizeSmall = other.numDigits;
			sizeLg = this.numDigits;
			
			if(this.negative){
				bNeg =true;
			}
			if(other.negative){
				sNeg = true;
			}
		}
		else if((numB == other.front && numS == this.front)){
			sizeSmall = this.numDigits;
			sizeLg = other.numDigits;
			
			if(this.negative){
				sNeg =true;
			}
			if(other.negative){
				bNeg = true;
			}
		}
		
		//set negative value for sum
		if(bNeg)
			 sum.negative = true;
	
		int carry = 0, sizeCtr=0;
		
		DigitNode numSum = new DigitNode(0,null);
		
		sum.front = numSum;
		
		//LOOP TO ADD VALUES IN
		while (numB != null){
			if(numS.next==null){
				numS.next = new DigitNode(0,null);
			}
			if(bNeg!=sNeg)
			{
				numS.digit = numS.digit*(-1);
			}	
			
			numSum.next= new DigitNode(carry+numB.digit+numS.digit,null);
			
			//if no need to carry
			if(numSum.next.digit>=0 && numSum.next.digit<9){
				carry = 0;
			}
			//if you have to carry over a 1
			if(numSum.next.digit>9){
				carry=1;
				numSum.next.digit = numSum.next.digit-10;
			}
			//if you need to borrow a 1
			else if(numSum.digit<0){
				if(numS.next!=null){
				carry = -1;
				numSum.next.digit = numSum.next.digit+10;
				}
			}
			
			numS = numS.next;
			numSum = numSum.next;
			sizeCtr++;
			if(numB.next !=null)
				numB = numB.next;
			else
				break;
		}
		
		if(carry ==1){
			DigitNode numr = new DigitNode(carry,null);
			numSum.next = numr;
			sizeCtr++;
		}	
		
		numSum = sum.front.next;
		
		/*while(numSum!=null){
			DigitNode prev = new DigitNode(numSum.digit,null)	;
			if(numSum.digit==0 && numSum.next==null){
				numSum.digit = null;
			}
			numSum = numSum.next;
		}*/
		
		sum.numDigits = sizeCtr;
		sum.front= sum.front.next;
		return sum;
	}
	
	
	
	/**
	 * Returns the BigInteger obtained by multiplying the given BigInteger
	 * with this BigInteger - DOES NOT MODIFY this BigInteger
	 * 
	 * @param other BigInteger to be multiplied
	 * @return A new BigInteger which is the product of this BigInteger and other.
	 */
	public BigInteger multiply(BigInteger other) {
		// THE FOLLOWING LINE IS A PLACEHOLDER SO THE PROGRAM COMPILES
		// YOU WILL NEED TO CHANGE IT TO RETURN THE APPROPRIATE BigInteger
		
		BigInteger prod = new BigInteger();
		
		int carry=0;
		
		DigitNode numB = this.front;	
		DigitNode numS = other.front;
		
		if(this.numDigits>other.numDigits){
			DigitNode temp = numB;
			numB = numS;
			numS = temp;
		}
		
		DigitNode numP = new DigitNode(0,null);
		prod.front = numP;
		DigitNode numShold= numS;
		DigitNode numPhold = numP;
		while(numB!=null){
			
			while(numS!=null){
				
				if(numP.next != null)
				numP.next= new DigitNode(carry+numP.next.digit+(numB.digit*numS.digit),null);
				else if(numP.next == null)
					numP.next= new DigitNode((numB.digit*numS.digit)+carry,null);
				
				
				if(numP.next.digit>9){				
					carry = numP.next.digit/10;
					numP.next.digit = numP.next.digit%10;
				}
				else if(numP.next.digit<=9){
					carry = 0;
				}
				
				numP = numP.next;
				
				if(numS.next !=null)
					numS = numS.next;
				else
					break;
			}	
			if(carry!=0){
				numP.next = new DigitNode(carry,null);
				carry = 0;
			}	
		numP = numP.next;
			//numP = numP.next;
			numS = numShold.next;
		
			numP = numPhold.next;
			
			if(numB.next !=null)
				numB = numB.next;
			else
				break;
		}
		
		
		
		if(carry !=0){
			DigitNode numr = new DigitNode(carry,null);
			numP.next = numr;
		}
		prod.front = prod.front.next;
		
		if(this.negative == other.negative){
			prod.negative = false;
		}
		else prod.negative = true;
		
		double size = 0;
		
		size = (Math.floor(Math.log10((double)this.numDigits)+Math.log10((double)other.numDigits)))+1;
		prod.numDigits = (int)size;
		
		return prod;
		
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		if (front == null) {
			return "0";
		}
		
		String retval = front.digit + "";
		for (DigitNode curr = front.next; curr != null; curr = curr.next) {
				retval = curr.digit + retval;
		}
		
		if (negative) {
			retval = '-' + retval;
		}
		
		return retval;
	}
	
}
